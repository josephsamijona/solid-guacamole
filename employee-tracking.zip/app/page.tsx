"use client"

import { useEffect, useRef } from "react"
import { motion, useAnimation, useInView } from "framer-motion"
import Image from "next/image"
import Link from "next/link"
import { ArrowRight, CheckCircle, Clock, QrCode, Shield, Users } from "lucide-react"
import { Button } from "@/components/ui/button"

export default function LandingPage() {
  return (
    <div className="flex min-h-screen flex-col">
      <Header />
      <main className="flex-1">
        <HeroSection />
        <FeaturesSection />
        <HowItWorksSection />
        <BenefitsSection />
        <CTASection />
      </main>
      <Footer />
    </div>
  )
}

function Header() {
  return (
    <header className="sticky top-0 z-50 w-full border-b bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60">
      <div className="container flex h-16 items-center justify-between">
        <div className="flex items-center gap-2">
          <QrCode className="h-6 w-6" />
          <span className="text-xl font-bold">AttendTrack</span>
        </div>
        <nav className="hidden md:flex gap-6">
          <Link href="#features" className="text-sm font-medium hover:text-primary">
            Features
          </Link>
          <Link href="#how-it-works" className="text-sm font-medium hover:text-primary">
            How It Works
          </Link>
          <Link href="#benefits" className="text-sm font-medium hover:text-primary">
            Benefits
          </Link>
          <Link href="#contact" className="text-sm font-medium hover:text-primary">
            Contact
          </Link>
        </nav>
        <div className="flex items-center gap-4">
          <Button variant="outline" size="sm" className="hidden md:flex">
            Log In
          </Button>
          <Button size="sm">Get Started</Button>
        </div>
      </div>
    </header>
  )
}

function AnimatedSection({ children, className }) {
  const controls = useAnimation()
  const ref = useRef(null)
  const inView = useInView(ref, { once: true, threshold: 0.2 })

  useEffect(() => {
    if (inView) {
      controls.start("visible")
    }
  }, [controls, inView])

  return (
    <motion.section
      ref={ref}
      initial="hidden"
      animate={controls}
      variants={{
        hidden: { opacity: 0 },
        visible: { opacity: 1, transition: { duration: 0.5, staggerChildren: 0.2 } },
      }}
      className={className}
    >
      {children}
    </motion.section>
  )
}

function AnimatedElement({ children, className, delay = 0, x = 0, y = 0 }) {
  return (
    <motion.div
      variants={{
        hidden: { opacity: 0, x, y },
        visible: {
          opacity: 1,
          x: 0,
          y: 0,
          transition: {
            duration: 0.5,
            delay,
          },
        },
      }}
      className={className}
    >
      {children}
    </motion.div>
  )
}

function HeroSection() {
  return (
    <AnimatedSection className="container py-20 md:py-24">
      <div className="grid gap-8 md:grid-cols-2 md:gap-12 items-center">
        <div className="space-y-6">
          <AnimatedElement y={20}>
            <h1 className="text-4xl font-bold tracking-tight sm:text-5xl md:text-6xl">
              Employee Attendance <span className="text-primary">Simplified</span>
            </h1>
          </AnimatedElement>
          <AnimatedElement y={20} delay={0.1}>
            <p className="text-xl text-muted-foreground">
              Track employee attendance effortlessly with our QR code-based system. Save time, increase accuracy, and
              streamline your HR processes.
            </p>
          </AnimatedElement>
          <AnimatedElement y={20} delay={0.2}>
            <div className="flex flex-col sm:flex-row gap-4">
              <Button size="lg" className="gap-2">
                Get Started <ArrowRight className="h-4 w-4" />
              </Button>
              <Button variant="outline" size="lg">
                Book a Demo
              </Button>
            </div>
          </AnimatedElement>
        </div>
        <AnimatedElement x={50}>
          <div className="relative h-[400px] w-full rounded-lg overflow-hidden shadow-xl">
            <Image
              src="/placeholder.svg?height=800&width=800"
              alt="Employee scanning QR code"
              fill
              className="object-cover"
            />
          </div>
        </AnimatedElement>
      </div>
    </AnimatedSection>
  )
}

function FeaturesSection() {
  const features = [
    {
      icon: <QrCode className="h-10 w-10 text-primary" />,
      title: "QR Code Check-in",
      description: "Employees simply scan their unique QR code to check in and out, eliminating manual time tracking.",
    },
    {
      icon: <Clock className="h-10 w-10 text-primary" />,
      title: "Real-time Tracking",
      description: "Monitor attendance in real-time with instant notifications for late arrivals or absences.",
    },
    {
      icon: <Users className="h-10 w-10 text-primary" />,
      title: "Time-Off Management",
      description: "Streamlined request and approval process for vacations, sick days, and other time off.",
    },
    {
      icon: <Shield className="h-10 w-10 text-primary" />,
      title: "Secure & Reliable",
      description: "Enterprise-grade security ensures your employee data is always protected and available.",
    },
  ]

  return (
    <AnimatedSection id="features" className="container py-20 md:py-24">
      <AnimatedElement y={20}>
        <div className="text-center mb-16">
          <h2 className="text-3xl font-bold tracking-tight sm:text-4xl md:text-5xl">Powerful Features</h2>
          <p className="mt-4 text-xl text-muted-foreground max-w-3xl mx-auto">
            Our attendance tracking system combines simplicity with powerful capabilities
          </p>
        </div>
      </AnimatedElement>

      <div className="grid gap-8 md:grid-cols-2 lg:grid-cols-4">
        {features.map((feature, index) => (
          <AnimatedElement key={index} y={20} delay={index * 0.1}>
            <div className="flex flex-col items-center text-center p-6 rounded-lg border bg-card">
              {feature.icon}
              <h3 className="mt-4 text-xl font-medium">{feature.title}</h3>
              <p className="mt-2 text-muted-foreground">{feature.description}</p>
            </div>
          </AnimatedElement>
        ))}
      </div>
    </AnimatedSection>
  )
}

function HowItWorksSection() {
  const steps = [
    {
      number: "01",
      title: "Generate QR Codes",
      description: "Create unique QR codes for each employee that links to their profile in the system.",
    },
    {
      number: "02",
      title: "Employee Check-in",
      description: "Employees scan their QR code when arriving at work using any mobile device or dedicated scanner.",
    },
    {
      number: "03",
      title: "Automatic Tracking",
      description: "The system automatically records time stamps and calculates hours worked, breaks, and overtime.",
    },
    {
      number: "04",
      title: "Generate Reports",
      description: "Access comprehensive attendance reports, analytics, and insights with just a few clicks.",
    },
  ]

  return (
    <AnimatedSection id="how-it-works" className="py-20 md:py-24 bg-muted">
      <div className="container">
        <AnimatedElement y={20}>
          <div className="text-center mb-16">
            <h2 className="text-3xl font-bold tracking-tight sm:text-4xl md:text-5xl">How It Works</h2>
            <p className="mt-4 text-xl text-muted-foreground max-w-3xl mx-auto">
              Our simple four-step process makes attendance tracking effortless
            </p>
          </div>
        </AnimatedElement>

        <div className="grid gap-8 md:grid-cols-2 lg:grid-cols-4">
          {steps.map((step, index) => (
            <AnimatedElement key={index} y={20} delay={index * 0.1}>
              <div className="relative p-6 bg-background rounded-lg border">
                <div className="absolute -top-4 -left-4 flex items-center justify-center w-12 h-12 rounded-full bg-primary text-primary-foreground font-bold">
                  {step.number}
                </div>
                <h3 className="mt-6 text-xl font-medium">{step.title}</h3>
                <p className="mt-2 text-muted-foreground">{step.description}</p>
              </div>
            </AnimatedElement>
          ))}
        </div>
      </div>
    </AnimatedSection>
  )
}

function BenefitsSection() {
  const benefits = [
    "Reduce time spent on manual attendance tracking by up to 80%",
    "Eliminate buddy punching and time theft",
    "Improve payroll accuracy and reduce errors",
    "Gain insights into attendance patterns and trends",
    "Simplify compliance with labor regulations",
    "Enhance employee accountability and transparency",
  ]

  return (
    <AnimatedSection id="benefits" className="container py-20 md:py-24">
      <div className="grid gap-8 md:grid-cols-2 items-center">
        <AnimatedElement x={-50}>
          <div className="relative h-[400px] w-full rounded-lg overflow-hidden shadow-xl">
            <Image
              src="/placeholder.svg?height=800&width=800"
              alt="Dashboard showing attendance data"
              fill
              className="object-cover"
            />
          </div>
        </AnimatedElement>
        <div className="space-y-6">
          <AnimatedElement y={20}>
            <h2 className="text-3xl font-bold tracking-tight sm:text-4xl">Why Choose AttendTrack?</h2>
          </AnimatedElement>
          <AnimatedElement y={20} delay={0.1}>
            <p className="text-lg text-muted-foreground">
              Our QR code-based attendance system delivers tangible benefits for businesses of all sizes:
            </p>
          </AnimatedElement>
          <AnimatedElement y={20} delay={0.2}>
            <ul className="space-y-3">
              {benefits.map((benefit, index) => (
                <li key={index} className="flex items-start gap-2">
                  <CheckCircle className="h-5 w-5 text-primary mt-0.5" />
                  <span>{benefit}</span>
                </li>
              ))}
            </ul>
          </AnimatedElement>
        </div>
      </div>
    </AnimatedSection>
  )
}

function CTASection() {
  return (
    <AnimatedSection className="bg-primary text-primary-foreground py-16 md:py-20">
      <div className="container text-center space-y-6">
        <AnimatedElement y={20}>
          <h2 className="text-3xl font-bold tracking-tight sm:text-4xl">
            Ready to Modernize Your Attendance Tracking?
          </h2>
        </AnimatedElement>
        <AnimatedElement y={20} delay={0.1}>
          <p className="text-xl max-w-2xl mx-auto opacity-90">
            Join thousands of businesses that have simplified their attendance management with AttendTrack.
          </p>
        </AnimatedElement>
        <AnimatedElement y={20} delay={0.2}>
          <div className="flex flex-col sm:flex-row gap-4 justify-center mt-4">
            <Button size="lg" variant="secondary" className="gap-2">
              Start Free Trial <ArrowRight className="h-4 w-4" />
            </Button>
            <Button
              size="lg"
              variant="outline"
              className="bg-transparent border-primary-foreground hover:bg-primary-foreground hover:text-primary"
            >
              Contact Sales
            </Button>
          </div>
        </AnimatedElement>
      </div>
    </AnimatedSection>
  )
}

function Footer() {
  return (
    <footer className="border-t py-12 md:py-16">
      <div className="container">
        <div className="grid gap-8 md:grid-cols-2 lg:grid-cols-4">
          <div className="space-y-4">
            <div className="flex items-center gap-2">
              <QrCode className="h-6 w-6" />
              <span className="text-xl font-bold">AttendTrack</span>
            </div>
            <p className="text-muted-foreground">Modern attendance tracking for the modern workplace.</p>
          </div>

          <div>
            <h3 className="font-medium mb-4">Product</h3>
            <ul className="space-y-2">
              <li>
                <Link href="#" className="text-muted-foreground hover:text-foreground">
                  Features
                </Link>
              </li>
              <li>
                <Link href="#" className="text-muted-foreground hover:text-foreground">
                  Pricing
                </Link>
              </li>
              <li>
                <Link href="#" className="text-muted-foreground hover:text-foreground">
                  Integrations
                </Link>
              </li>
              <li>
                <Link href="#" className="text-muted-foreground hover:text-foreground">
                  FAQ
                </Link>
              </li>
            </ul>
          </div>

          <div>
            <h3 className="font-medium mb-4">Company</h3>
            <ul className="space-y-2">
              <li>
                <Link href="#" className="text-muted-foreground hover:text-foreground">
                  About
                </Link>
              </li>
              <li>
                <Link href="#" className="text-muted-foreground hover:text-foreground">
                  Blog
                </Link>
              </li>
              <li>
                <Link href="#" className="text-muted-foreground hover:text-foreground">
                  Careers
                </Link>
              </li>
              <li>
                <Link href="#" className="text-muted-foreground hover:text-foreground">
                  Contact
                </Link>
              </li>
            </ul>
          </div>

          <div>
            <h3 className="font-medium mb-4">Legal</h3>
            <ul className="space-y-2">
              <li>
                <Link href="#" className="text-muted-foreground hover:text-foreground">
                  Privacy Policy
                </Link>
              </li>
              <li>
                <Link href="#" className="text-muted-foreground hover:text-foreground">
                  Terms of Service
                </Link>
              </li>
              <li>
                <Link href="#" className="text-muted-foreground hover:text-foreground">
                  Cookie Policy
                </Link>
              </li>
            </ul>
          </div>
        </div>

        <div className="mt-12 pt-6 border-t text-center text-sm text-muted-foreground">
          <p>© {new Date().getFullYear()} AttendTrack. All rights reserved.</p>
        </div>
      </div>
    </footer>
  )
}
